﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}

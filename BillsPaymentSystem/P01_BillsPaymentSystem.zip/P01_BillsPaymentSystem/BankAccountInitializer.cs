﻿using P01_BillsPaymentSystem.Data.Models;

namespace P01_BillsPaymentSystem
{
    public class BankAccountInitializer
    {
        //public static BankAccount[] GetBankAccounts()
        //{
        //    BankAccount[] bankAccounts = new BankAccount[]
        //    {
        //        new BankAccount(){ BankName = "Poor Bank", SWIFTCode = "segdrg23", Balance = 32832m},
        //        new BankAccount(){ BankName = "Firey Bank", SWIFTCode = "segdrg23", Balance = 129m},
        //        new BankAccount(){ BankName = "dioej Bank", SWIFTCode = "segdrg23", Balance = 29842m},
        //        new BankAccount(){ BankName = "Pasdoor Bank", SWIFTCode = "segdrg23", Balance = 1132m},
        //        new BankAccount(){ BankName = "Posssor Bank", SWIFTCode = "segdrg23", Balance = 98832m},
        //        new BankAccount(){ BankName = "Poyrteor Bank", SWIFTCode = "segdrg23", Balance = 9832m},
        //        new BankAccount(){ BankName = "Smale Bank", SWIFTCode = "segdrg23", Balance = 1922m},

        //    };
        //    return bankAccounts;
        //}
    }
}
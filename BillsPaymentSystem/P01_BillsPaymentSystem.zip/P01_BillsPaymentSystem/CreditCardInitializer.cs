﻿using P01_BillsPaymentSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem
{
    public class CreditCardInitializer
    {
        //public static CreditCard[] GetCreditCards()
        //{
        //    CreditCard[] creditCards = new CreditCard[]
        //    {
        //        new CreditCard(){ Limit = 3000, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(3)},
        //        new CreditCard(){ Limit = 3400, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(6)},
        //        new CreditCard(){ Limit = 23000, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(12)},
        //        new CreditCard(){ Limit = 300, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(4)},
        //        new CreditCard(){ Limit = 120, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(19)},
        //        new CreditCard(){ Limit = 8900, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(13)},
        //        new CreditCard(){ Limit = 1200, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(23)},
        //        new CreditCard(){ Limit = 4300, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(13)},
        //        new CreditCard(){ Limit = 900, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(31)},
        //        new CreditCard(){ Limit = 4560, MoneyOwed = 0, ExpirationDate = DateTime.Now.AddMonths(17)},

        //    };
        //    return creditCards;
        //}
    }
}

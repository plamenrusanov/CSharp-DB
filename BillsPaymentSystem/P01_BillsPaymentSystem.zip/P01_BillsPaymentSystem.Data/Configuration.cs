﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConectionString = 
            @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;Database=PaymentSystem;" +
            "Integrated Security=True";
    }
}

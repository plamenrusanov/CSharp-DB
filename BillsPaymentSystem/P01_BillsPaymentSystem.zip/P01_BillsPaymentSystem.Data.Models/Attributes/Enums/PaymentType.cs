﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem.Data.Models.Attributes.Enums
{
    public enum PaymentType
    {
        BankAccount,
        CreditCard
    }
}

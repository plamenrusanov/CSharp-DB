﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntroDBApps
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;DATABASE=MinionsDB;Integrated Security=True";
    }
}

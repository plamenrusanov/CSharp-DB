namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-D1G8VKM\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}